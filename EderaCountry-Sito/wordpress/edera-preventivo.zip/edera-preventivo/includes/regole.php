<?php
/**
 * Le regole del Preventivo flash: valori iniziali, lettura, controllo e salvataggio.
 *
 * Tutte le regole stanno in una sola opzione di WordPress ("edera_preventivo_regole"), un array con le sezioni
 * spazi, durate, calendario, tariffe, sconti, servizi (servizi e dotazioni), testi e generali. I conti li fa il
 * browser (assets/calcolo.js) con queste regole: il server non riceve e non salva le richieste.
 *
 * @package edera-preventivo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const EDERA_PREVENTIVO_OPZIONE = 'edera_preventivo_regole';

/**
 * Testo della mail iniziale: lo stesso del calcolatore del sito originale.
 *
 * @return string
 */
function edera_preventivo_corpo_iniziale() {
	return "Richiesta di preventivo, Edera Country House\n\n"
		. "Azienda: {azienda}\nEmail: {email}\nTelefono: {telefono}\nTipologia di evento: {tipo}\n"
		. "Spazi: {spazi}\nData: {data}\nPartecipanti: {persone}\nDurata: {durata}\n{servizi_riga}"
		. "Stima location: {totale}\n\nImporto indicativo, da confermare con la struttura.";
}

/**
 * Le regole di oggi (le stesse del calcolatore di ederacountry.it e di config/preventivo.php del tema Edera).
 *
 * @return array
 */
function edera_preventivo_iniziali() {
	return array(
		'versione'   => 1,
		'spazi'      => array(
			array( 'chiave' => 'rustico', 'nome' => 'Rustico', 'persone' => 50, 'modo' => 'persone', 'base' => 400, 'incluse' => 20, 'a_persona' => 15, 'prezzo_intera' => 0, 'prezzo_mezza' => 0, 'mezza' => false, 'attivo' => true, 'scelto' => true, 'nota' => '', 'fasce' => array() ),
			array( 'chiave' => 'serra', 'nome' => 'Serra', 'persone' => 70, 'modo' => 'persone', 'base' => 250, 'incluse' => 20, 'a_persona' => 5, 'prezzo_intera' => 0, 'prezzo_mezza' => 0, 'mezza' => false, 'attivo' => true, 'scelto' => false, 'nota' => '', 'fasce' => array() ),
			array( 'chiave' => 'piscina', 'nome' => 'Piscina', 'persone' => 30, 'modo' => 'fisso', 'base' => 0, 'incluse' => 0, 'a_persona' => 0, 'prezzo_intera' => 400, 'prezzo_mezza' => 300, 'mezza' => true, 'attivo' => true, 'scelto' => false, 'nota' => '', 'fasce' => array() ),
			array( 'chiave' => 'esterno', 'nome' => 'Spazio esterno', 'persone' => 120, 'modo' => 'persone', 'base' => 350, 'incluse' => 20, 'a_persona' => 2.5, 'prezzo_intera' => 0, 'prezzo_mezza' => 0, 'mezza' => false, 'attivo' => true, 'scelto' => false, 'nota' => '', 'fasce' => array() ),
		),
		'durate'     => array(
			'intera'        => 'Giornata intera',
			'mezza'         => 'Mezza giornata',
			'mezza_attiva'  => true,
			'regola_mezza'  => 'almeno_uno',
			'nota_mezza_si' => 'Per la piscina puoi scegliere mezza giornata o giornata intera.',
			'nota_mezza_no' => 'Per gli spazi selezionati è prevista la giornata intera.',
		),
		'calendario' => array(
			'date_escluse'   => array(),
			'periodi_chiusi' => array(),
			'giorni_chiusi'  => array(),
			'preavviso'      => 0,
			'finestra_mesi'  => 0,
		),
		'tariffe'    => array(
			array( 'nome' => 'Tariffa stagionale', 'attiva' => true, 'tipo' => 'mesi', 'mesi' => array( 10, 11, 12, 1, 2, 3 ), 'giorni' => array(), 'dal' => '', 'al' => '', 'modo' => 'importo', 'valore' => 125, 'applica' => 'primo_spazio', 'spazi' => array(), 'riga' => false ),
		),
		'sconti'     => array(
			'piu_spazi'      => array( 'attivo' => false, 'da' => 2, 'modo' => 'percentuale', 'valore' => 0, 'nome' => 'Sconto per più spazi' ),
			'persone'        => array( 'attivo' => false, 'oltre' => 50, 'modo' => 'percentuale', 'valore' => 0, 'nome' => 'Sconto per gruppi numerosi' ),
			'minimo_persone' => 0,
			'spesa_minima'   => 0,
			'arrotonda'      => array( 'modo' => 'nessuno', 'passo' => 10 ),
		),
		'servizi'    => array(),
		'testi'      => array(
			'email'            => 'edera@ederacountry.it',
			'oggetto'          => 'Richiesta di preventivo, {azienda}',
			'corpo'            => edera_preventivo_corpo_iniziale(),
			'avvertenza'       => 'Il prezzo indicato è orientativo e non definitivo: il preventivo finale può variare in base alla tipologia di evento, ai servizi richiesti e alle esigenze organizzative. Valori da confermare con la struttura.',
			'iva'              => 'personalizzata',
			'nota_prezzo'      => 'IVA e servizi extra da verificare',
			'msg_data'         => 'Questa data non è disponibile: scegline un’altra.',
			'msg_capienza'     => 'Con gli spazi scelti si arriva al massimo a {max} persone: la stima è calcolata su {max}.',
			// oltre la capienza, quando si puo' superare (dalla 1.0.1)
			'nota_capienza'    => 'Capienza indicativa con gli spazi scelti: {capienza} persone. Per gruppi più numerosi la richiesta viene valutata.',
			'msg_oltre'        => '{persone} persone, oltre la capienza indicata di {capienza}: da valutare con la struttura.',
			'nota_fisso'       => '{spazi} a prezzo fisso: l’importo indicato non tiene conto delle persone in più.',
			'da_valutare'      => 'Da valutare con la struttura',
			// fasce per numero di persone (dalla 1.0.1): "Rustico (31-50 persone, 15 € a persona)"
			'fascia_etichetta' => '{spazio} ({fascia}, {prezzo})',
			'fascia_limiti'    => '{da}-{a} persone',
			'fascia_aperta'    => 'da {da} persone',
			'fascia_fissa'     => 'prezzo fisso',
			'fascia_persona'   => '{importo} a persona',
			'msg_fuori_fascia' => '{spazio}: per {persone} persone non c’è una fascia di prezzo, la stima usa il prezzo standard dello spazio.',
		),
		'generali'   => array(
			'partecipanti_esempio' => 20,
			// rigido = il numero torna alla capienza (com'e' oggi); stima = si supera, con l'importo; senza = si supera, senza importo
			'oltre_capienza'       => 'rigido',
			'massimo_assoluto'     => 0,
		),
	);
}

/**
 * Le voci aggiunte a una tariffa nella 1.1.0, con i valori che danno i conti di prima: su tutti gli spazi,
 * sommata al prezzo dello spazio.
 *
 * @return array
 */
function edera_preventivo_tariffa_nuove() {
	return array(
		'spazi' => array(), // chiavi degli spazi su cui vale (vuoto = tutti)
		'riga'  => false,   // riga a parte nella stima ("Riscaldamento (Rustico, Serra)")
	);
}

/**
 * Le voci aggiunte a un servizio nella 1.1.0, con i valori che danno i conti di prima: un servizio extra, senza
 * quantita', senza fasce, sempre disponibile.
 *
 * @return array
 */
function edera_preventivo_servizio_nuove() {
	return array(
		'gruppo'            => 'servizio',  // dotazione | servizio
		'quantita'          => 'cliente',   // con il prezzo a pezzo: cliente (la scrive chi compila) | automatica
		'persone_per_pezzo' => 1,           // automatica: un pezzo ogni N partecipanti, arrotondato per eccesso
		'massimo'           => 0,           // pezzi disponibili (0 = nessun limite)
		'comprese'          => 0,           // pezzi compresi nell'affitto prima del prezzo
		'unita'             => '',          // un pezzo, al singolare ("sedia"); vuoto = "pezzo"
		'unita_plurale'     => '',          // al plurale ("sedie"); vuoto = "pezzi"
		'fasce'             => array(),     // per numero di partecipanti: da, a (0 = senza limite), modo, importo
		'spazi'             => array(),     // disponibile solo con questi spazi (vuoto = sempre)
	);
}

/**
 * Le voci del listino del sito originale (PDF "Servizi e dotazioni"), per il bottone "Aggiungi le voci del
 * listino": tutte spente, i prezzi da mettere sono a 0. Le fasce della pulizia finale non ci sono: le decide la
 * struttura.
 *
 * @return array
 */
function edera_preventivo_listino() {
	$voce = function ( $v ) {
		return array_merge(
			array( 'nome' => '', 'prezzo' => 0, 'modo' => 'fisso', 'attivo' => false, 'nota' => '' ),
			edera_preventivo_servizio_nuove(),
			$v
		);
	};
	return array(
		$voce( array( 'nome' => __( 'Tavoli', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'incluso', 'massimo' => 12, 'persone_per_pezzo' => 8, 'nota' => __( 'Tavoli da 6-8 persone', 'edera-preventivo' ), 'unita' => __( 'tavolo', 'edera-preventivo' ), 'unita_plurale' => __( 'tavoli', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Panche', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'incluso', 'massimo' => 19, 'persone_per_pezzo' => 4, 'unita' => __( 'panca', 'edera-preventivo' ), 'unita_plurale' => __( 'panche', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Sedie', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'incluso', 'massimo' => 65, 'unita' => __( 'sedia', 'edera-preventivo' ), 'unita_plurale' => __( 'sedie', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Area piscina', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'incluso', 'nota' => __( '12 lettini, 9 sedie, 2 tavolini, 4 ombrelloni', 'edera-preventivo' ), 'spazi' => array( 'piscina' ) ) ),
		$voce( array( 'nome' => __( 'Audio e video', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'fisso', 'nota' => __( 'TV, casse, proiettore, microfoni, consolle', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Gazebo', 'edera-preventivo' ), 'gruppo' => 'dotazione', 'modo' => 'pezzo', 'quantita' => 'cliente', 'massimo' => 4, 'unita' => __( 'gazebo', 'edera-preventivo' ), 'unita_plurale' => __( 'gazebo', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Grill', 'edera-preventivo' ), 'prezzo' => 80, 'nota' => __( 'Barbecue per cotture all’aperto', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Casetta bar', 'edera-preventivo' ), 'prezzo' => 50, 'nota' => __( 'Con frigorifero, freezer e lavandino', 'edera-preventivo' ) ) ),
		$voce( array( 'nome' => __( 'Pulizia finale', 'edera-preventivo' ), 'nota' => __( 'Da 80 a 300 €, in base alla tipologia di evento e al numero di partecipanti', 'edera-preventivo' ) ) ),
	);
}

/**
 * Le regole di config/preventivo.php del tema Edera, se il tema attivo ce l'ha (quelle che il committente
 * poteva aver gia' cambiato), portate nella forma del plugin. Altrimenti i valori iniziali.
 *
 * @return array
 */
function edera_preventivo_dal_tema() {
	$r = edera_preventivo_iniziali();
	$f = get_template_directory() . '/config/preventivo.php';
	if ( ! file_exists( $f ) ) {
		return $r;
	}
	$c = include $f;
	if ( ! is_array( $c ) || empty( $c['spazi'] ) || ! is_array( $c['spazi'] ) ) {
		return $r;
	}
	$spazi = array();
	foreach ( $c['spazi'] as $k => $s ) {
		$fisso   = isset( $s['intera'] );
		$spazi[] = array(
			'chiave'        => sanitize_key( $k ),
			'nome'          => isset( $s['nome'] ) ? (string) $s['nome'] : (string) $k,
			'persone'       => isset( $s['persone'] ) ? (int) $s['persone'] : 1,
			'modo'          => $fisso ? 'fisso' : 'persone',
			'base'          => isset( $s['base'] ) ? (float) $s['base'] : 0,
			'incluse'       => isset( $s['incluse'] ) ? (int) $s['incluse'] : 0,
			'a_persona'     => isset( $s['a_persona'] ) ? (float) $s['a_persona'] : 0,
			'prezzo_intera' => $fisso ? (float) $s['intera'] : 0,
			'prezzo_mezza'  => isset( $s['mezza'] ) ? (float) $s['mezza'] : 0,
			'mezza'         => isset( $s['mezza'] ),
			'attivo'        => true,
			'scelto'        => ! empty( $s['scelto'] ),
			'nota'          => '',
			'fasce'         => array(),
		);
	}
	$r['spazi'] = $spazi;
	if ( isset( $c['email'] ) ) {
		$r['testi']['email'] = (string) $c['email'];
	}
	if ( isset( $c['partecipanti_esempio'] ) ) {
		$r['generali']['partecipanti_esempio'] = (int) $c['partecipanti_esempio'];
	}
	if ( isset( $c['stagione']['mesi'], $c['stagione']['supplemento'] ) ) {
		$r['tariffe'][0]['mesi']   = array_map( 'intval', (array) $c['stagione']['mesi'] );
		$r['tariffe'][0]['valore'] = (float) $c['stagione']['supplemento'];
	}
	foreach ( array( 'nota_mezza_si', 'nota_mezza_no' ) as $k ) {
		if ( isset( $c[ $k ] ) ) {
			$r['durate'][ $k ] = (string) $c[ $k ];
		}
	}
	if ( isset( $c['avvertenza'] ) ) {
		$r['testi']['avvertenza'] = (string) $c['avvertenza'];
	}
	$v = edera_preventivo_controlla( $r );
	return $v['errori'] ? edera_preventivo_iniziali() : $v['regole'];
}

/**
 * Le regole salvate (o quelle iniziali, se non ce ne sono ancora).
 *
 * @return array
 */
function edera_preventivo_regole() {
	$r = get_option( EDERA_PREVENTIVO_OPZIONE );
	if ( ! is_array( $r ) || empty( $r['spazi'] ) ) {
		return edera_preventivo_iniziali();
	}
	// una sezione o una voce che manca (aggiunta in una versione successiva del plugin) prende i valori iniziali:
	// le regole salvate con la 1.0.0 non hanno "oltre_capienza", quindi restano a "rigido" come prima
	$ini = edera_preventivo_iniziali();
	$r   = array_replace( $ini, array_intersect_key( $r, $ini ) );
	foreach ( array( 'durate', 'calendario', 'sconti', 'testi', 'generali' ) as $k ) {
		$r[ $k ] = is_array( $r[ $k ] ) ? array_replace( $ini[ $k ], $r[ $k ] ) : $ini[ $k ];
	}
	// tariffe e servizi salvati con la 1.0.x: le voci nuove della 1.1.0 prendono i valori che danno gli stessi conti
	// (tariffa su tutti gli spazi e sommata al prezzo dello spazio; servizio extra, senza quantita' ne' fasce)
	foreach ( array( 'tariffe' => edera_preventivo_tariffa_nuove(), 'servizi' => edera_preventivo_servizio_nuove() ) as $k => $nuove ) {
		$righe = array();
		foreach ( is_array( $r[ $k ] ) ? $r[ $k ] : array() as $x ) {
			if ( is_array( $x ) ) {
				$righe[] = $x + $nuove;
			}
		}
		$r[ $k ] = $righe;
	}
	return $r;
}

/**
 * Il calendario ha regole (giorni esclusi, chiusure, preavviso, finestra)?
 *
 * @param array $r Regole.
 * @return bool
 */
function edera_preventivo_calendario_attivo( $r ) {
	$c = $r['calendario'];
	return ! empty( $c['date_escluse'] ) || ! empty( $c['periodi_chiusi'] ) || ! empty( $c['giorni_chiusi'] ) || (int) $c['preavviso'] > 0 || (int) $c['finestra_mesi'] > 0;
}

/**
 * Una data Y-m-d valida?
 *
 * @param string $d Data.
 * @return bool
 */
function edera_preventivo_data_valida( $d ) {
	if ( ! is_string( $d ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $d, $m ) ) {
		return false;
	}
	return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
}

/**
 * Pulisce e controlla le fasce per numero di persone di uno spazio o di una voce dei servizi e dotazioni. Una riga
 * del tutto vuota si salta. Ogni fascia: da (almeno 1), a (vuoto = senza limite superiore, altrimenti non minore di
 * "da"), tipo di prezzo (fisso per la fascia o a persona; per le voci anche a pezzo), importo e, solo per gli
 * spazi, l'importo facoltativo per la mezza giornata. Le fasce si salvano in ordine di "da" e non devono
 * sovrapporsi.
 *
 * @param mixed    $in     Fasce grezze.
 * @param string   $nome   Nome dello spazio o della voce (per i messaggi).
 * @param callable $prezzo Controllo di un importo.
 * @param callable $intero Lettura di un numero intero.
 * @param array    $e      Errori (per riferimento).
 * @param bool     $voce   Fasce di una voce dei servizi e dotazioni (dalla 1.1.0).
 * @return array
 */
function edera_preventivo_controlla_fasce( $in, $nome, $prezzo, $intero, &$e, $voce = false ) {
	$out = array();
	foreach ( array_values( (array) $in ) as $f ) {
		$f   = (array) $f;
		$val = function ( $k ) use ( $f ) {
			return isset( $f[ $k ] ) && is_scalar( $f[ $k ] ) ? trim( (string) $f[ $k ] ) : '';
		};
		if ( '' === $val( 'da' ) && '' === $val( 'a' ) && '' === $val( 'importo' ) && '' === $val( 'importo_mezza' ) ) {
			continue;
		}
		$quale = ( '' === $val( 'da' ) ? '?' : $val( 'da' ) ) . ( '' === $val( 'a' ) ? '+' : '-' . $val( 'a' ) );
		/* translators: 1: tier (e.g. 31-50), 2: space or item name */
		$dove = sprintf( $voce ? __( 'fascia %1$s della voce "%2$s"', 'edera-preventivo' ) : __( 'fascia %1$s dello spazio "%2$s"', 'edera-preventivo' ), $quale, $nome );
		$da   = $intero( $val( 'da' ) );
		$a    = '' === $val( 'a' ) ? 0 : $intero( $val( 'a' ) );
		if ( null === $da || $da < 1 ) {
			/* translators: %s: where */
			$e[] = sprintf( __( '"Da" deve essere un numero di persone, almeno 1: %s.', 'edera-preventivo' ), $dove );
			$da  = 1;
		}
		if ( null === $a || $a < 0 ) {
			/* translators: %s: where */
			$e[] = sprintf( __( '"A" deve essere un numero di persone, oppure vuoto per "senza limite": %s.', 'edera-preventivo' ), $dove );
			$a   = 0;
		} elseif ( $a > 0 && $da > $a ) {
			/* translators: %s: where */
			$e[] = sprintf( __( '"Da" non può essere maggiore di "a": %s.', 'edera-preventivo' ), $dove );
		}
		if ( '' === $val( 'importo' ) ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Manca l’importo: %s.', 'edera-preventivo' ), $dove );
		}
		if ( $voce ) {
			$out[] = array(
				'da'      => $da,
				'a'       => $a,
				'modo'    => isset( $f['modo'] ) && in_array( $f['modo'], array( 'persona', 'pezzo' ), true ) ? $f['modo'] : 'fisso',
				'importo' => $prezzo( $val( 'importo' ), $dove ),
			);
			continue;
		}
		$out[] = array(
			'da'            => $da,
			'a'             => $a,
			'modo'          => isset( $f['modo'] ) && 'persona' === $f['modo'] ? 'persona' : 'fisso',
			'importo'       => $prezzo( $val( 'importo' ), $dove ),
			'importo_mezza' => '' === $val( 'importo_mezza' ) ? null : $prezzo( $val( 'importo_mezza' ), $dove ),
		);
	}
	usort(
		$out,
		function ( $x, $y ) {
			return $x['da'] - $y['da'];
		}
	);
	$testo = function ( $x ) {
		return $x['da'] . ( $x['a'] ? '-' . $x['a'] : '+' );
	};
	for ( $i = 1; $i < count( $out ); $i++ ) {
		$prima = $out[ $i - 1 ];
		if ( 0 === $prima['a'] || $prima['a'] >= $out[ $i ]['da'] ) {
			$e[] = $voce
				/* translators: 1: item name, 2: first tier, 3: second tier */
				? sprintf( __( 'Le fasce della voce "%1$s" si sovrappongono: %2$s e %3$s persone. Ogni numero di persone deve stare in una fascia sola.', 'edera-preventivo' ), $nome, $testo( $prima ), $testo( $out[ $i ] ) )
				/* translators: 1: space name, 2: first tier, 3: second tier */
				: sprintf( __( 'Le fasce dello spazio "%1$s" si sovrappongono: %2$s e %3$s persone. Ogni numero di persone deve stare in una fascia sola.', 'edera-preventivo' ), $nome, $testo( $prima ), $testo( $out[ $i ] ) );
		}
	}
	return $out;
}

/**
 * Pulisce e controlla le regole (dal modulo di amministrazione o da un file JSON importato).
 * Niente prezzi negativi, percentuali fra 0 e 100, date nel formato AAAA-MM-GG, numeri interi dove servono.
 *
 * @param mixed $in Dati grezzi.
 * @return array array( 'regole' => regole pulite, 'errori' => messaggi ).
 */
function edera_preventivo_controlla( $in ) {
	$e   = array();
	$ini = edera_preventivo_iniziali();
	$in  = is_array( $in ) ? $in : array();
	$num = function ( $v ) {
		$v = is_string( $v ) ? str_replace( ',', '.', trim( $v ) ) : $v;
		return is_numeric( $v ) ? (float) $v : null;
	};
	$intero = function ( $v ) use ( $num ) {
		$n = $num( $v );
		return null === $n ? null : (int) round( $n );
	};
	$si     = function ( $v ) {
		return ! empty( $v ) && '0' !== $v && 'false' !== $v;
	};
	$testo  = function ( $v, $righe = false ) {
		$v = is_scalar( $v ) ? (string) $v : '';
		return $righe ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
	};
	$prezzo = function ( $v, $dove ) use ( $num, &$e ) {
		if ( '' === $v || null === $v ) {
			return 0.0;
		}
		$n = $num( $v );
		if ( null === $n ) {
			/* translators: %s: where the wrong value is */
			$e[] = sprintf( __( 'Numero non valido: %s.', 'edera-preventivo' ), $dove );
			return 0.0;
		}
		if ( $n < 0 ) {
			/* translators: %s: where the wrong value is */
			$e[] = sprintf( __( 'I prezzi non possono essere negativi: %s.', 'edera-preventivo' ), $dove );
			return 0.0;
		}
		return round( $n, 2 );
	};
	$quota  = function ( $modo, $v, $dove ) use ( $prezzo, &$e ) {
		$n = $prezzo( $v, $dove );
		if ( 'percentuale' === $modo && $n > 100 ) {
			/* translators: %s: where the wrong value is */
			$e[] = sprintf( __( 'Le percentuali vanno da 0 a 100: %s.', 'edera-preventivo' ), $dove );
			$n = 100.0;
		}
		return $n;
	};
	$lista_num = function ( $v, $min, $max ) {
		$out = array();
		foreach ( (array) $v as $x ) {
			if ( is_numeric( $x ) && (int) $x >= $min && (int) $x <= $max && ! in_array( (int) $x, $out, true ) ) {
				$out[] = (int) $x;
			}
		}
		return $out;
	};
	$r = array( 'versione' => 1 );

	// spazi
	$r['spazi'] = array();
	$chiavi     = array();
	foreach ( array_values( isset( $in['spazi'] ) ? (array) $in['spazi'] : array() ) as $i => $s ) {
		$s    = (array) $s;
		$nome = $testo( isset( $s['nome'] ) ? $s['nome'] : '' );
		if ( '' === $nome ) {
			continue; // riga vuota
		}
		/* translators: %s: space name */
		$dove   = sprintf( __( 'spazio "%s"', 'edera-preventivo' ), $nome );
		$chiave = sanitize_key( isset( $s['chiave'] ) && '' !== $s['chiave'] ? $s['chiave'] : remove_accents( $nome ) );
		$chiave = '' === $chiave ? 'spazio' : $chiave;
		$base_k = $chiave;
		for ( $n = 2; in_array( $chiave, $chiavi, true ); $n++ ) {
			$chiave = $base_k . '-' . $n;
		}
		$chiavi[] = $chiave;
		$persone  = $intero( isset( $s['persone'] ) ? $s['persone'] : '' );
		if ( null === $persone || $persone < 1 ) {
			/* translators: %s: where the wrong value is */
			$e[]     = sprintf( __( 'La capienza deve essere almeno 1 persona: %s.', 'edera-preventivo' ), $dove );
			$persone = 1;
		}
		$incluse = $intero( isset( $s['incluse'] ) ? $s['incluse'] : 0 );
		if ( null === $incluse || $incluse < 0 ) {
			/* translators: %s: where the wrong value is */
			$e[]     = sprintf( __( 'Le persone comprese nel prezzo base non possono essere negative: %s.', 'edera-preventivo' ), $dove );
			$incluse = 0;
		}
		$modo         = isset( $s['modo'] ) && 'fisso' === $s['modo'] ? 'fisso' : 'persone';
		$fasce        = edera_preventivo_controlla_fasce( isset( $s['fasce'] ) ? $s['fasce'] : array(), $nome, $prezzo, $intero, $e );
		$r['spazi'][] = array(
			'chiave'        => $chiave,
			'nome'          => $nome,
			'persone'       => $persone,
			'modo'          => $modo,
			'base'          => $prezzo( isset( $s['base'] ) ? $s['base'] : 0, $dove ),
			'incluse'       => $incluse,
			'a_persona'     => $prezzo( isset( $s['a_persona'] ) ? $s['a_persona'] : 0, $dove ),
			'prezzo_intera' => $prezzo( isset( $s['prezzo_intera'] ) ? $s['prezzo_intera'] : 0, $dove ),
			'prezzo_mezza'  => $prezzo( isset( $s['prezzo_mezza'] ) ? $s['prezzo_mezza'] : 0, $dove ),
			'mezza'         => $si( isset( $s['mezza'] ) ? $s['mezza'] : false ),
			'attivo'        => $si( isset( $s['attivo'] ) ? $s['attivo'] : false ),
			'scelto'        => $si( isset( $s['scelto'] ) ? $s['scelto'] : false ),
			'nota'          => $testo( isset( $s['nota'] ) ? $s['nota'] : '' ),
			'fasce'         => $fasce,
		);
	}
	$attivi = array_filter(
		$r['spazi'],
		function ( $s ) {
			return $s['attivo'];
		}
	);
	if ( ! $attivi ) {
		$e[] = __( 'Serve almeno uno spazio attivo.', 'edera-preventivo' );
	}
	// gli spazi scelti in una tariffa o in una voce (dalla 1.1.0): le chiavi che non ci sono piu' si tolgono, in
	// ordine di pagina. Se erano tutte di spazi tolti, la regola varrebbe per tutti gli spazi: meglio dirlo.
	$lista_spazi = function ( $v, $dove ) use ( $chiavi, &$e ) {
		$dati = array();
		foreach ( (array) $v as $k ) {
			if ( is_scalar( $k ) && '' !== sanitize_key( (string) $k ) ) {
				$dati[] = sanitize_key( (string) $k );
			}
		}
		$out = array_values( array_intersect( $chiavi, $dati ) );
		if ( $dati && ! $out ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Gli spazi spuntati non ci sono più: %s. Spunta gli spazi giusti, oppure nessuno.', 'edera-preventivo' ), $dove );
		}
		return $out;
	};

	// durate
	$d           = isset( $in['durate'] ) ? (array) $in['durate'] : array();
	$r['durate'] = array(
		'intera'        => $testo( isset( $d['intera'] ) ? $d['intera'] : '' ),
		'mezza'         => $testo( isset( $d['mezza'] ) ? $d['mezza'] : '' ),
		'mezza_attiva'  => $si( isset( $d['mezza_attiva'] ) ? $d['mezza_attiva'] : false ),
		'regola_mezza'  => isset( $d['regola_mezza'] ) && 'tutti' === $d['regola_mezza'] ? 'tutti' : 'almeno_uno',
		'nota_mezza_si' => $testo( isset( $d['nota_mezza_si'] ) ? $d['nota_mezza_si'] : '' ),
		'nota_mezza_no' => $testo( isset( $d['nota_mezza_no'] ) ? $d['nota_mezza_no'] : '' ),
	);
	foreach ( array( 'intera', 'mezza' ) as $k ) {
		if ( '' === $r['durate'][ $k ] ) {
			$r['durate'][ $k ] = $ini['durate'][ $k ];
		}
	}

	// calendario
	$c    = isset( $in['calendario'] ) ? (array) $in['calendario'] : array();
	$cal  = array(
		'date_escluse'   => array(),
		'periodi_chiusi' => array(),
		'giorni_chiusi'  => $lista_num( isset( $c['giorni_chiusi'] ) ? $c['giorni_chiusi'] : array(), 1, 7 ),
		'preavviso'      => 0,
		'finestra_mesi'  => 0,
	);
	foreach ( array_values( isset( $c['date_escluse'] ) ? (array) $c['date_escluse'] : array() ) as $x ) {
		$x    = (array) $x;
		$data = trim( isset( $x['data'] ) ? (string) $x['data'] : '' );
		if ( '' === $data ) {
			continue;
		}
		if ( ! edera_preventivo_data_valida( $data ) ) {
			/* translators: %s: date */
			$e[] = sprintf( __( 'Data esclusa non valida (si scrive AAAA-MM-GG): %s.', 'edera-preventivo' ), $data );
			continue;
		}
		$cal['date_escluse'][] = array(
			'data' => $data,
			'nota' => $testo( isset( $x['nota'] ) ? $x['nota'] : '' ),
		);
	}
	foreach ( array_values( isset( $c['periodi_chiusi'] ) ? (array) $c['periodi_chiusi'] : array() ) as $x ) {
		$x   = (array) $x;
		$dal = trim( isset( $x['dal'] ) ? (string) $x['dal'] : '' );
		$al  = trim( isset( $x['al'] ) ? (string) $x['al'] : '' );
		if ( '' === $dal && '' === $al ) {
			continue;
		}
		if ( ! edera_preventivo_data_valida( $dal ) || ! edera_preventivo_data_valida( $al ) || $dal > $al ) {
			/* translators: 1: start date, 2: end date */
			$e[] = sprintf( __( 'Periodo di chiusura non valido (date AAAA-MM-GG, "dal" prima di "al"): %1$s, %2$s.', 'edera-preventivo' ), $dal, $al );
			continue;
		}
		$cal['periodi_chiusi'][] = array(
			'dal'  => $dal,
			'al'   => $al,
			'nota' => $testo( isset( $x['nota'] ) ? $x['nota'] : '' ),
		);
	}
	$pre = $intero( isset( $c['preavviso'] ) && '' !== $c['preavviso'] ? $c['preavviso'] : 0 );
	if ( null === $pre || $pre < 0 || $pre > 365 ) {
		$e[] = __( 'Il preavviso va da 0 a 365 giorni.', 'edera-preventivo' );
		$pre = 0;
	}
	$fin = $intero( isset( $c['finestra_mesi'] ) && '' !== $c['finestra_mesi'] ? $c['finestra_mesi'] : 0 );
	if ( null === $fin || $fin < 0 || $fin > 60 ) {
		$e[] = __( 'La finestra di prenotazione va da 0 a 60 mesi.', 'edera-preventivo' );
		$fin = 0;
	}
	$cal['preavviso']     = $pre;
	$cal['finestra_mesi'] = $fin;
	$r['calendario']      = $cal;

	// tariffe e supplementi
	$r['tariffe'] = array();
	foreach ( array_values( isset( $in['tariffe'] ) ? (array) $in['tariffe'] : array() ) as $t ) {
		$t    = (array) $t;
		$nome = $testo( isset( $t['nome'] ) ? $t['nome'] : '' );
		if ( '' === $nome ) {
			continue;
		}
		/* translators: %s: surcharge name */
		$dove = sprintf( __( 'tariffa "%s"', 'edera-preventivo' ), $nome );
		$tipo = isset( $t['tipo'] ) && in_array( $t['tipo'], array( 'mesi', 'giorni', 'periodo' ), true ) ? $t['tipo'] : 'mesi';
		$modo = isset( $t['modo'] ) && 'percentuale' === $t['modo'] ? 'percentuale' : 'importo';
		$riga = array(
			'nome'    => $nome,
			'attiva'  => $si( isset( $t['attiva'] ) ? $t['attiva'] : false ),
			'tipo'    => $tipo,
			'mesi'    => $lista_num( isset( $t['mesi'] ) ? $t['mesi'] : array(), 1, 12 ),
			'giorni'  => $lista_num( isset( $t['giorni'] ) ? $t['giorni'] : array(), 1, 7 ),
			'dal'     => trim( isset( $t['dal'] ) ? (string) $t['dal'] : '' ),
			'al'      => trim( isset( $t['al'] ) ? (string) $t['al'] : '' ),
			'modo'    => $modo,
			'valore'  => $quota( $modo, isset( $t['valore'] ) ? $t['valore'] : 0, $dove ),
			'applica' => isset( $t['applica'] ) && in_array( $t['applica'], array( 'primo_spazio', 'ogni_spazio', 'totale' ), true ) ? $t['applica'] : 'totale',
			'spazi'   => $lista_spazi( isset( $t['spazi'] ) ? $t['spazi'] : array(), $dove ),
			'riga'    => $si( isset( $t['riga'] ) ? $t['riga'] : false ),
		);
		if ( 'mesi' === $tipo && ! $riga['mesi'] ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Scegli almeno un mese: %s.', 'edera-preventivo' ), $dove );
		}
		if ( 'giorni' === $tipo && ! $riga['giorni'] ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Scegli almeno un giorno della settimana: %s.', 'edera-preventivo' ), $dove );
		}
		if ( 'periodo' === $tipo && ( ! edera_preventivo_data_valida( $riga['dal'] ) || ! edera_preventivo_data_valida( $riga['al'] ) || $riga['dal'] > $riga['al'] ) ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Periodo non valido (date AAAA-MM-GG, "dal" prima di "al"): %s.', 'edera-preventivo' ), $dove );
		}
		$r['tariffe'][] = $riga;
	}

	// sconti e minimi
	$s  = isset( $in['sconti'] ) ? (array) $in['sconti'] : array();
	$ps = isset( $s['piu_spazi'] ) ? (array) $s['piu_spazi'] : array();
	$pp = isset( $s['persone'] ) ? (array) $s['persone'] : array();
	$ar = isset( $s['arrotonda'] ) ? (array) $s['arrotonda'] : array();
	$sc = array(
		'piu_spazi'      => array(
			'attivo' => $si( isset( $ps['attivo'] ) ? $ps['attivo'] : false ),
			'da'     => max( 2, (int) $intero( isset( $ps['da'] ) ? $ps['da'] : 2 ) ),
			'modo'   => isset( $ps['modo'] ) && 'importo' === $ps['modo'] ? 'importo' : 'percentuale',
			'valore' => 0,
			'nome'   => $testo( isset( $ps['nome'] ) && '' !== $ps['nome'] ? $ps['nome'] : $ini['sconti']['piu_spazi']['nome'] ),
		),
		'persone'        => array(
			'attivo' => $si( isset( $pp['attivo'] ) ? $pp['attivo'] : false ),
			'oltre'  => max( 1, (int) $intero( isset( $pp['oltre'] ) ? $pp['oltre'] : 1 ) ),
			'modo'   => isset( $pp['modo'] ) && 'importo' === $pp['modo'] ? 'importo' : 'percentuale',
			'valore' => 0,
			'nome'   => $testo( isset( $pp['nome'] ) && '' !== $pp['nome'] ? $pp['nome'] : $ini['sconti']['persone']['nome'] ),
		),
		'minimo_persone' => max( 0, (int) $intero( isset( $s['minimo_persone'] ) && '' !== $s['minimo_persone'] ? $s['minimo_persone'] : 0 ) ),
		'spesa_minima'   => $prezzo( isset( $s['spesa_minima'] ) ? $s['spesa_minima'] : 0, __( 'spesa minima', 'edera-preventivo' ) ),
		'arrotonda'      => array(
			'modo'  => isset( $ar['modo'] ) && in_array( $ar['modo'], array( 'nessuno', 'eccesso', 'difetto', 'vicino' ), true ) ? $ar['modo'] : 'nessuno',
			'passo' => $prezzo( isset( $ar['passo'] ) ? $ar['passo'] : 10, __( 'arrotondamento', 'edera-preventivo' ) ),
		),
	);
	$sc['piu_spazi']['valore'] = $quota( $sc['piu_spazi']['modo'], isset( $ps['valore'] ) ? $ps['valore'] : 0, $sc['piu_spazi']['nome'] );
	$sc['persone']['valore']   = $quota( $sc['persone']['modo'], isset( $pp['valore'] ) ? $pp['valore'] : 0, $sc['persone']['nome'] );
	if ( 'nessuno' !== $sc['arrotonda']['modo'] && $sc['arrotonda']['passo'] <= 0 ) {
		$e[] = __( 'Per arrotondare serve un passo maggiore di zero (per esempio 10 euro).', 'edera-preventivo' );
	}
	$r['sconti'] = $sc;

	// servizi e dotazioni (fino alla 1.0.1 "servizi aggiuntivi": nome, prezzo fisso o a persona, attivo, nota)
	$r['servizi'] = array();
	foreach ( array_values( isset( $in['servizi'] ) ? (array) $in['servizi'] : array() ) as $x ) {
		$x    = (array) $x;
		$nome = $testo( isset( $x['nome'] ) ? $x['nome'] : '' );
		if ( '' === $nome ) {
			continue;
		}
		/* translators: %s: item name */
		$dove     = sprintf( __( 'voce "%s"', 'edera-preventivo' ), $nome );
		$modo     = isset( $x['modo'] ) && in_array( $x['modo'], array( 'fisso', 'persona', 'pezzo', 'incluso' ), true ) ? $x['modo'] : 'fisso';
		$quantita = isset( $x['quantita'] ) && 'automatica' === $x['quantita'] ? 'automatica' : 'cliente';
		$numero   = function ( $k, $vuoto, $minimo, $messaggio ) use ( $x, $intero, $dove, &$e ) {
			$n = $intero( isset( $x[ $k ] ) && '' !== $x[ $k ] ? $x[ $k ] : $vuoto );
			if ( null === $n || $n < $minimo ) {
				$e[] = sprintf( $messaggio, $dove );
				return $vuoto;
			}
			return $n;
		};
		/* translators: %s: where */
		$massimo  = $numero( 'massimo', 0, 0, __( 'Il massimo disponibile non può essere negativo (0 = nessun limite): %s.', 'edera-preventivo' ) );
		/* translators: %s: where */
		$comprese = $numero( 'comprese', 0, 0, __( 'I pezzi compresi nell’affitto non possono essere negativi: %s.', 'edera-preventivo' ) );
		$ogni     = $intero( isset( $x['persone_per_pezzo'] ) && '' !== $x['persone_per_pezzo'] ? $x['persone_per_pezzo'] : 1 );
		if ( null === $ogni || $ogni < 1 ) {
			if ( 'pezzo' === $modo && 'automatica' === $quantita ) {
				/* translators: %s: where */
				$e[] = sprintf( __( 'Con la quantità automatica, "un pezzo ogni quante persone" deve essere almeno 1: %s.', 'edera-preventivo' ), $dove );
			}
			$ogni = 1;
		}
		if ( $massimo > 0 && $comprese > $massimo ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'I pezzi compresi nell’affitto non possono essere più del massimo disponibile: %s.', 'edera-preventivo' ), $dove );
		}
		$fasce = edera_preventivo_controlla_fasce( isset( $x['fasce'] ) ? $x['fasce'] : array(), $nome, $prezzo, $intero, $e, true );
		if ( 'pezzo' !== $modo && in_array( 'pezzo', wp_list_pluck( $fasce, 'modo' ), true ) ) {
			/* translators: %s: where */
			$e[] = sprintf( __( 'Le fasce "a pezzo" valgono solo con il prezzo "a pezzo": %s.', 'edera-preventivo' ), $dove );
		}
		$r['servizi'][] = array(
			'nome'              => $nome,
			'prezzo'            => $prezzo( isset( $x['prezzo'] ) ? $x['prezzo'] : 0, $dove ),
			'modo'              => $modo,
			'attivo'            => $si( isset( $x['attivo'] ) ? $x['attivo'] : false ),
			'nota'              => $testo( isset( $x['nota'] ) ? $x['nota'] : '' ),
			'gruppo'            => isset( $x['gruppo'] ) && 'dotazione' === $x['gruppo'] ? 'dotazione' : 'servizio',
			'quantita'          => $quantita,
			'persone_per_pezzo' => $ogni,
			'massimo'           => $massimo,
			'comprese'          => $comprese,
			'unita'             => $testo( isset( $x['unita'] ) ? $x['unita'] : '' ),
			'unita_plurale'     => $testo( isset( $x['unita_plurale'] ) ? $x['unita_plurale'] : '' ),
			'fasce'             => $fasce,
			'spazi'             => $lista_spazi( isset( $x['spazi'] ) ? $x['spazi'] : array(), $dove ),
		);
	}

	// testi e invio
	$t          = isset( $in['testi'] ) ? (array) $in['testi'] : array();
	$r['testi'] = array();
	$nuovi = array( 'nota_capienza', 'msg_oltre', 'nota_fisso', 'da_valutare', 'fascia_etichetta', 'fascia_limiti', 'fascia_aperta', 'fascia_fissa', 'fascia_persona', 'msg_fuori_fascia' );
	foreach ( array_merge( array( 'oggetto', 'avvertenza', 'nota_prezzo', 'msg_data', 'msg_capienza' ), $nuovi ) as $k ) {
		$r['testi'][ $k ] = $testo( isset( $t[ $k ] ) ? $t[ $k ] : '' );
	}
	// a capo come nella mail di oggi ("\n"): il modulo del pannello manda "\r\n"
	$r['testi']['corpo'] = str_replace( array( "\r\n", "\r" ), "\n", $testo( isset( $t['corpo'] ) ? $t['corpo'] : '', true ) );
	$r['testi']['iva']   = isset( $t['iva'] ) && in_array( $t['iva'], array( 'personalizzata', 'inclusa', 'esclusa', 'nessuna' ), true ) ? $t['iva'] : 'personalizzata';
	$email               = sanitize_email( isset( $t['email'] ) ? $t['email'] : '' );
	if ( ! is_email( $email ) ) {
		$e[]   = __( 'L’email che riceve le richieste non è valida.', 'edera-preventivo' );
		$email = $ini['testi']['email'];
	}
	$r['testi']['email'] = $email;
	// la riga "oltre la capienza" e le etichette delle fasce devono esserci sempre: un testo vuoto (o un file
	// esportato con la 1.0.0) prende quello iniziale
	foreach ( array_merge( array( 'oggetto', 'corpo' ), $nuovi ) as $k ) {
		if ( '' === trim( $r['testi'][ $k ] ) ) {
			$r['testi'][ $k ] = $ini['testi'][ $k ];
		}
	}

	// generali
	$g     = isset( $in['generali'] ) ? (array) $in['generali'] : array();
	$esemp = $intero( isset( $g['partecipanti_esempio'] ) ? $g['partecipanti_esempio'] : 20 );
	if ( null === $esemp || $esemp < 1 ) {
		$e[]   = __( 'I partecipanti d’esempio devono essere almeno 1.', 'edera-preventivo' );
		$esemp = 20;
	}
	$oltre = isset( $g['oltre_capienza'] ) && in_array( $g['oltre_capienza'], array( 'rigido', 'stima', 'senza' ), true ) ? $g['oltre_capienza'] : 'rigido';
	$assol = $intero( isset( $g['massimo_assoluto'] ) && '' !== $g['massimo_assoluto'] ? $g['massimo_assoluto'] : 0 );
	if ( null === $assol || $assol < 0 ) {
		$e[]   = __( 'Il massimo assoluto di partecipanti non può essere negativo (0 = nessun massimo).', 'edera-preventivo' );
		$assol = 0;
	}
	if ( $assol > 0 && $r['sconti']['minimo_persone'] > $assol ) {
		$e[] = __( 'Il minimo di partecipanti non può superare il massimo assoluto.', 'edera-preventivo' );
	}
	$r['generali'] = array(
		'partecipanti_esempio' => $esemp,
		'oltre_capienza'       => $oltre,
		'massimo_assoluto'     => $assol,
	);

	return array(
		'regole' => $r,
		'errori' => array_values( array_unique( $e ) ),
	);
}
